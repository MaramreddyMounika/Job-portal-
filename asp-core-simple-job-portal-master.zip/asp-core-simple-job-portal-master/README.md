﻿## Asp .NET Core Job Portal

#### An open source online job portal.

Used Tech Stack

1. Asp .NET Core
2. MySql

### Screenshots

## Home page
<img src="screenshots/one.png" height="800">

## Add new position as employer
<img src="screenshots/two.png" height="800">

## Job details
<img src="screenshots/three.png" height="800">

Show your support by 🌟 the project!!